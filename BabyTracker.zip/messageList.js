exports.error = {	
	errorMessage : "Sorry, I can\'t complete the order now. Please try later again."
}

exports.message = {
	askBabyName : "What is your baby\'s name?",
}